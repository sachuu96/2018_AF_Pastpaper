import React from 'react';
import "bootstrap/dist/css/bootstrap.min.css"
import CourseView from './components/ViewCourses'
import './App.css';

function App() {
  return (
    <div className="App">
        <CourseView/>
    </div>
  );
}

export default App;
